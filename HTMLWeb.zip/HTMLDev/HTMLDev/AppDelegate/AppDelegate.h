//
//  AppDelegate.h
//  HTMLDev
//
//  Created by ZhuHong on 2018/7/31.
//  Copyright © 2018年 CoderHG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

