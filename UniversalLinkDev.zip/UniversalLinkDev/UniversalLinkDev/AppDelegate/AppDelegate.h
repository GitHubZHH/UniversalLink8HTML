//
//  AppDelegate.h
//  UniversalLinkDev
//
//  Created by ZhuHong on 2018/7/30.
//  Copyright © 2018年 CoderHG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

